# Barbearia · Site e sistema de agendamento

Site da barbearia (landing page) + sistema de contas, agendamento, planos mensais e painel de gestão.
HTML, CSS e JavaScript puros (sem build) + [Supabase](https://supabase.com) (login, banco de dados e regras de segurança).

## Como o site funciona

1. A **landing page** (`index.html`) apresenta a barbearia.
2. Todo botão de **agendar** ou **comprar plano** leva para `app/`, onde a pessoa **cria a conta** ou **entra** (e-mail e senha de no mínimo 8 caracteres, ou Google).
   Só entra quem já criou a conta: o botão "Entrar com Google" sem cadastro prévio é bloqueado.
3. Depois do login, abre o **painel** com menu: Início, Agendar, Meus agendamentos, Planos e Configurações.
   Quem é dono, gerente ou profissional vê também o grupo **Gestão**: Agenda, Serviços e preços, Clientes, Financeiro e Barbearia.

## Estrutura

```
index.html                  landing page
assets/                     vídeo, imagens e quadros do tour (img/, video/, tour/)
equipe/                     fotos dos profissionais (wesley.jpg, anderson.jpg)
app/
  index.html                login/cadastro + painel
  app.js                    login, menu e telas do cliente (agendar, meus agendamentos, planos, configurações)
  admin.js                  telas de gestão (agenda, serviços, clientes, financeiro, barbearia)
  app.css                   visual do sistema
docs/
  CONFIGURACAO.md           passo a passo: Supabase, Google, Vercel e e-mails
  emails/                   modelos de e-mail (confirmar cadastro, redefinir senha)
database/
  bootstrap-owner.sql       como definir o proprietário
tools/build-bundle.py       gera dist/barbearia-completo.html (site inteiro em um único arquivo)
vercel.json                 cabeçalhos de cache e segurança
```

## Rodar no computador

Qualquer servidor estático serve (não abra o arquivo com duplo clique: o login com Google precisa de `http://`).

```bash
python3 -m http.server 3000      # ou: npx serve -l 3000 .
# abra http://localhost:3000
```

## Publicar na Vercel

1. Crie o repositório no GitHub e envie estes arquivos.
2. Na Vercel: *Add New → Project*, importe o repositório. **Framework Preset: Other**, sem comando de build, diretório de saída: a raiz.
3. Configure o Supabase com o endereço publicado (veja `docs/CONFIGURACAO.md`).

Cada `git push` na branch principal publica de novo.

## Segurança

- O código usa **somente chaves públicas** (URL e chave *publishable* do Supabase). Nunca coloque aqui o Client Secret do Google nem a chave `service_role`.
- Todas as regras sensíveis (horário livre, reserva sem conflito, créditos do plano, permissões de dono e profissional) ficam **no banco**, com RLS e funções seguras. A interface só chama essas funções.
- Dados dos clientes só aparecem para quem tem permissão no painel.
